bool hasWebGL() => true; // fora da Web assumimos ok
